
EN   Your CAD data on 26.05.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 536270 ADN-32-15-A-P-A 
    
    AIS2017, 536270 ADN-32-15-A-P-A---(asm_0), 536267 ADN-15-P-A_(KS).ipt
    AIS2017, 536270 ADN-32-15-A-P-A---(asm_0), DIN-439-B - M10x1_25(F).ipt
    AIS2017, 536270 ADN-32-15-A-P-A---(asm_0), 536267 ADN-15-P---(Z).ipt
    AIS2017, 536270 ADN-32-15-A-P-A---(asm_0), 536270 ADN-32-15-A-P-A---(asm_0).iam
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    
